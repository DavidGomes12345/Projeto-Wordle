package lat.jack.wordle.wordle.State;

public enum LoginState {

    GUEST_USER,
    SIGNED_IN;
}
