package lat.jack.wordle.wordle.Objects;

import javafx.scene.image.ImageView;
import javafx.scene.text.Text;

public class Key {

    public ImageView keyView;
    public Text keyText;
    public String keyValue;
    public String keyType;
}
