package lat.jack.wordle.wordle;

public class Launcher {

    // Launcher Class
    // Loophole to create a runnable fat jar with all the required JavaFX dependencies.

    public static void main(String[] args) {
        Main.main(args);
    }
}
