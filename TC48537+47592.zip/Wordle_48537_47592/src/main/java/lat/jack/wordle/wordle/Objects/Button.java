package lat.jack.wordle.wordle.Objects;

import javafx.scene.image.ImageView;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Text;

public class Button {

    public ImageView buttonView;
    public StackPane buttonPane;
    public Text buttonText;
    public String buttonValue;

    public String buttonColour;
    public String buttonSize;
}
