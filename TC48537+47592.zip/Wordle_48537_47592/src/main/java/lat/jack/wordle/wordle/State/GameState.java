package lat.jack.wordle.wordle.State;

public enum GameState {

    PRE_START,
    STARTING,
    ACTIVE,
    WON,
    LOSS,
    END;
}
