package lat.jack.wordle.wordle.Objects;

public class User {

    public int userID;
    public String userName;
}
