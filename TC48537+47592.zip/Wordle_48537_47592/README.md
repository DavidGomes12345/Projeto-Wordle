# Wordle Java

Wordle recreated in Java (Also has a SQLite authentication system to keep scores)

### Gameplay - (Wrong Word)

![](https://i.imgur.com/AqxsaOE.png)
### User Personal Statistics

![](https://i.imgur.com/XOxSFjm.png)

### Leaderboard
![](https://i.imgur.com/srl2HfS.png)